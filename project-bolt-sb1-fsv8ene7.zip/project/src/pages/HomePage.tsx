import { useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import Header from '../components/Header';
import Hero from '../components/Hero';
import TemplateShowcase from '../components/TemplateShowcase';
import FeaturesSection from '../components/FeaturesSection';
import TemplateGallery from '../components/TemplateGallery';
import AIAdBot from '../components/AIAdBot';
import SmartChatBot from '../components/SmartChatBot';
import FinalCTA from '../components/FinalCTA';
import BackToTop from '../components/BackToTop';
import type { Template } from '../types';
import { openVoiceflowBot, PlanType } from '../utils/voiceflow';

export default function HomePage() {
  const [searchParams] = useSearchParams();
  const plan = searchParams.get('plan') as PlanType;

  useEffect(() => {
    if (plan && window.location.hash === '#templates') {
      setTimeout(() => {
        const element = document.getElementById('templates');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  }, [plan]);

  const handleSelectTemplate = (_template: Template) => {
    if (plan) {
      openVoiceflowBot(plan);
    } else {
      openVoiceflowBot('website');
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <section id="website">
        <TemplateShowcase />
      </section>
      <FeaturesSection />
      <section id="templates">
        <TemplateGallery onSelectTemplate={handleSelectTemplate} />
      </section>
      <section id="ads">
        <AIAdBot />
      </section>
      <section id="assistant">
        <SmartChatBot />
      </section>
      <section id="help">
        <FinalCTA />
      </section>

      <BackToTop />
    </div>
  );
}
