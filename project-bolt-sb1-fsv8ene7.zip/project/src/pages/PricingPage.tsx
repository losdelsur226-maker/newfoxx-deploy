import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowRight, Zap, Globe, Brain, MessageCircle, Megaphone, Crown } from 'lucide-react';
import Header from '../components/Header';
import BackToTop from '../components/BackToTop';
import { openVoiceflowBot } from '../utils/voiceflow';

interface PricingPlan {
  id: string;
  name: string;
  icon: React.ElementType;
  monthlyPrice: number;
  yearlyPrice: number;
  description: string;
  features: string[];
  badge?: string;
  hasWebsite: boolean;
}

const pricingPlans: PricingPlan[] = [
  {
    id: 'website',
    name: 'Website Builder',
    icon: Globe,
    monthlyPrice: 59,
    yearlyPrice: 49,
    description: 'AI builds your website instantly. Hosting, SEO, and domain included.',
    features: [
      'AI-powered website builder',
      'Free domain & SSL included',
      'Built-in SEO optimization',
      'Mobile-responsive design',
      'Fast cloud hosting'
    ],
    hasWebsite: true
  },
  {
    id: 'website_care',
    name: 'Website + Care',
    icon: Zap,
    monthlyPrice: 129,
    yearlyPrice: 109,
    description: 'Includes updates, security, and maintenance. Keeps your website optimized.',
    features: [
      'Everything in Website Builder',
      'Regular updates & backups',
      'Security monitoring',
      'Performance optimization',
      'Priority support'
    ],
    hasWebsite: true
  },
  {
    id: 'ads',
    name: 'AI Ad Bot',
    icon: Megaphone,
    monthlyPrice: 199,
    yearlyPrice: 179,
    description: 'Creates, manages, and optimizes your ad campaigns automatically.',
    features: [
      'AI-powered ad creation',
      'Multi-platform campaigns',
      'Automatic optimization',
      'Performance analytics',
      'Budget management'
    ],
    hasWebsite: false
  },
  {
    id: 'chatbot',
    name: 'Smart Chat Bot',
    icon: MessageCircle,
    monthlyPrice: 149,
    yearlyPrice: 129,
    description: '24/7 AI assistant that answers clients and includes maintenance.',
    features: [
      '24/7 automated responses',
      'Lead capture & qualification',
      'CRM integration',
      'Custom training',
      'Analytics dashboard'
    ],
    hasWebsite: false
  },
  {
    id: 'website_ads',
    name: 'Website + Ads',
    icon: Brain,
    monthlyPrice: 249,
    yearlyPrice: 219,
    description: 'Combines website automation and ad automation for full marketing.',
    features: [
      'Complete website package',
      'Full ad automation',
      'Integrated analytics',
      'Multi-channel marketing',
      'Dedicated support'
    ],
    hasWebsite: true
  },
  {
    id: 'full',
    name: 'Full AI System',
    icon: Crown,
    monthlyPrice: 299,
    yearlyPrice: 269,
    description: 'Website + Ads + Chat Bot + full SEO, hosting, and maintenance.',
    features: [
      'All features included',
      'Complete automation suite',
      'Priority support 24/7',
      'Advanced analytics',
      'White-glove onboarding'
    ],
    badge: 'Best Value',
    hasWebsite: true
  }
];

export default function PricingPage() {
  const [isYearly, setIsYearly] = useState(false);
  const navigate = useNavigate();

  const handleGetStarted = (plan: PricingPlan) => {
    if (plan.hasWebsite) {
      navigate(`/?plan=${plan.id}#templates`);
      setTimeout(() => {
        const element = document.getElementById('templates');
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      openVoiceflowBot(plan.id as 'ads' | 'chatbot');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0b0e14] via-[#0d1220] to-[#0b0e14]">
      <Header />

      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute top-40 right-20 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute bottom-20 left-1/2 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="relative z-10 pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
              Choose Your Plan — Automate Everything with{' '}
              <span className="bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
                NewFoxX AI
              </span>
            </h1>
            <p className="text-xl text-slate-300 mb-8">
              Compare monthly vs yearly pricing and save up to 20%
            </p>

            <div className="flex items-center justify-center gap-4 mb-4">
              <span className={`text-lg font-semibold transition-colors ${!isYearly ? 'text-white' : 'text-slate-400'}`}>
                Monthly
              </span>
              <button
                onClick={() => setIsYearly(!isYearly)}
                className="relative w-16 h-8 bg-slate-700 rounded-full transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                aria-label="Toggle pricing"
              >
                <div
                  className={`absolute top-1 left-1 w-6 h-6 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full shadow-lg transition-transform duration-300 ${
                    isYearly ? 'translate-x-8' : 'translate-x-0'
                  }`}
                ></div>
              </button>
              <span className={`text-lg font-semibold transition-colors ${isYearly ? 'text-white' : 'text-slate-400'}`}>
                Yearly
              </span>
              {isYearly && (
                <span className="px-3 py-1 bg-green-500/20 text-green-400 text-sm font-semibold rounded-full animate-fade-in">
                  Save 20%
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            {pricingPlans.map((plan) => {
              const Icon = plan.icon;
              const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;

              return (
                <div
                  key={plan.id}
                  className="relative group bg-[#0b0e14] rounded-2xl p-8 border border-transparent hover:border-blue-500/50 transition-all duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-blue-500/20 animate-fade-in"
                  style={{
                    background: 'linear-gradient(135deg, rgba(59, 130, 246, 0.05), rgba(168, 85, 247, 0.05))',
                  }}
                >
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-blue-500/20 opacity-0 group-hover:opacity-100 blur-xl transition-opacity duration-500"></div>

                  <div className="relative z-10">
                    {plan.badge && (
                      <div className="absolute -top-4 right-0">
                        <span className="px-4 py-1 bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-bold rounded-full shadow-lg">
                          {plan.badge}
                        </span>
                      </div>
                    )}

                    <div className="flex items-center gap-4 mb-6">
                      <div className="p-3 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl">
                        <Icon className="w-8 h-8 text-blue-400" />
                      </div>
                      <h3 className="text-2xl font-bold text-white">{plan.name}</h3>
                    </div>

                    <div className="mb-6">
                      <div className="flex items-baseline gap-2 mb-2">
                        <span className="text-5xl font-bold text-white">${price}</span>
                        <span className="text-slate-400 text-lg">/mo</span>
                        {isYearly && (
                          <span className="text-green-400 text-sm font-semibold">billed annually</span>
                        )}
                      </div>
                      <p className="text-slate-300 text-sm">{plan.description}</p>
                    </div>

                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, index) => (
                        <li key={index} className="flex items-start gap-3 text-slate-300">
                          <div className="mt-1 w-5 h-5 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                            <div className="w-2 h-2 rounded-full bg-blue-400"></div>
                          </div>
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <button
                      onClick={() => handleGetStarted(plan)}
                      className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl font-semibold hover:from-blue-500 hover:to-purple-500 transition-all duration-300 shadow-lg hover:shadow-xl hover:shadow-blue-500/50 group/btn"
                    >
                      Get Started
                      <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="text-center animate-fade-in">
            <p className="text-slate-400 text-lg">
              All plans include hosting, SSL security, and 24/7 technical support. Cancel or upgrade anytime.
            </p>
          </div>
        </div>
      </div>

      <BackToTop />
    </div>
  );
}
