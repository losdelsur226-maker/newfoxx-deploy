export type PlanType = 'website' | 'website_care' | 'ads' | 'chatbot' | 'website_ads' | 'full';

export const openVoiceflowBot = (plan: PlanType) => {
  if (typeof window !== 'undefined' && (window as any).voiceflow) {
    (window as any).voiceflow.chat.open();

    setTimeout(() => {
      (window as any).voiceflow.chat.interact({
        type: 'complete',
        payload: {
          plan: plan
        }
      });
    }, 500);
  }
};
