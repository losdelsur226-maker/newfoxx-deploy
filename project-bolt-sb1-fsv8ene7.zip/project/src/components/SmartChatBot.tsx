import { MessageCircle, Zap, Users, Brain } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Instant Replies',
    description: 'Never miss a message again. AI answers instantly, day or night.'
  },
  {
    icon: Users,
    title: 'Lead Capture',
    description: 'Collect names, emails, and bookings automatically.'
  },
  {
    icon: Brain,
    title: 'Smart Learning',
    description: 'The bot improves as it chats, adapting to your business tone.'
  }
];

const chatMessages = [
  { type: 'user', text: 'Hi, do you have availability this weekend?' },
  { type: 'bot', text: 'Yes! I can help you book your appointment instantly.' },
  { type: 'user', text: 'Wow, that\'s fast 😮' },
  { type: 'bot', text: 'All handled by NewFoxX AI 🦊✨' }
];

export default function SmartChatBot() {
  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden bg-gradient-to-b from-blue-950 via-[#0A1428] to-[#1B2A44]">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-64 bg-gradient-radial from-purple-500/20 via-blue-500/10 to-transparent blur-3xl opacity-60 pointer-events-none animate-glow-pulse"></div>

      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 -top-48 -right-48 bg-purple-500/10 rounded-full blur-3xl"></div>
        <div className="absolute w-96 h-96 -bottom-48 -left-48 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute w-64 h-64 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(147, 51, 234, 0.12) 1px, transparent 0)',
        backgroundSize: '40px 40px'
      }}></div>

      <div className="absolute -top-12 left-0 right-0 z-20 flex justify-center pointer-events-none">
        <p className="text-sm font-semibold text-white/70 tracking-wide animate-fade-in opacity-0" style={{ animationDelay: '0.3s', animationFillMode: 'forwards' }}>
          💬 From ads to conversations — your AI works around the clock.
        </p>
      </div>

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-500/10 border border-purple-500/20 rounded-full mb-6">
            <MessageCircle className="w-5 h-5 text-purple-400" />
            <span className="text-sm font-semibold text-purple-300">AI-Powered Support</span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
            Smart Chat Bot — Your{' '}
            <span className="bg-gradient-to-r from-purple-400 via-blue-400 to-cyan-400 text-transparent bg-clip-text">
              24/7 AI Assistant
            </span>
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Engage clients, answer questions, and capture leads — even while you sleep.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="relative group order-2 lg:order-1">
            <div className="absolute -inset-1 bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-500 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>
            <div className="relative bg-slate-900/80 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 shadow-2xl">
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-700">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">AI Chat</h3>
                  <p className="text-xs text-slate-400">Always online</p>
                </div>
              </div>

              <div className="space-y-4">
                {chatMessages.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in opacity-0`}
                    style={{ animationDelay: `${index * 0.4 + 0.5}s`, animationFillMode: 'forwards' }}
                  >
                    <div
                      className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                        message.type === 'user'
                          ? 'bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-400/30 text-white'
                          : 'bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-400/30 text-white animate-pulse-border'
                      }`}
                    >
                      <p className="text-sm leading-relaxed">{message.text}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-4 border-t border-slate-700">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span>AI is typing...</span>
                </div>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2">
            <p className="text-lg text-slate-300 leading-relaxed mb-8">
              From answering FAQs to booking clients and collecting leads — our AI Chat Bot handles conversations 24/7. It's trained for your business, customizable, and fully automated to capture every opportunity, even when you're offline.
            </p>

            <div className="space-y-4 mb-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div
                    key={index}
                    className="group bg-slate-800/50 backdrop-blur-sm border border-slate-700/50 rounded-xl p-5 hover:bg-slate-800/70 hover:border-purple-500/30 transition-all duration-300 hover:-translate-y-1"
                  >
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-purple-400/30 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                        <Icon className="w-6 h-6 text-purple-400" />
                      </div>
                      <div>
                        <h4 className="text-white font-semibold mb-1">{feature.title}</h4>
                        <p className="text-sm text-slate-400">{feature.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <button className="group relative px-8 py-4 bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-500 rounded-xl font-semibold text-white shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:-translate-y-1 overflow-hidden">
                <span className="relative z-10 flex items-center justify-center gap-2">
                  Add Smart Bot
                  <span className="group-hover:translate-x-1 transition-transform duration-300">→</span>
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-purple-600 via-blue-600 to-cyan-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </button>
              <button className="px-8 py-4 border-2 border-purple-400/30 rounded-xl font-semibold text-white hover:bg-purple-500/10 hover:border-purple-400/50 transition-all duration-300 hover:-translate-y-1">
                See It in Action
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
