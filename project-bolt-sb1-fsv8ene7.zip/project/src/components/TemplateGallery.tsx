import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import type { Template } from '../types';

interface TemplateGalleryProps {
  onSelectTemplate: (template: Template) => void;
}

const templates: Template[] = [
  {
    id: 'fashion-store',
    name: 'Fashion Store',
    description: 'Modern e-commerce with hero section, booking button, product gallery, and testimonials. Pink & white gradients.',
    imageUrl: 'https://images.pexels.com/photos/5632402/pexels-photo-5632402.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'E-commerce'
  },
  {
    id: 'hair-salon',
    name: 'Hair Salon',
    description: 'Elegant booking system with hero, design gallery, and customer testimonials. Soft pink theme.',
    imageUrl: 'https://images.pexels.com/photos/3993449/pexels-photo-3993449.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Beauty'
  },
  {
    id: 'barber-shop',
    name: 'Barber Shop',
    description: 'Professional grooming site with hero, appointment booking, style gallery, and reviews. Modern design.',
    imageUrl: 'https://images.pexels.com/photos/1813272/pexels-photo-1813272.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Beauty'
  },
  {
    id: 'fitness-gym',
    name: 'Fitness Gym',
    description: 'Dynamic gym website with hero banner, membership booking, workout gallery, and member testimonials.',
    imageUrl: 'https://images.pexels.com/photos/1954524/pexels-photo-1954524.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Fitness'
  },
  {
    id: 'auto-dealership',
    name: 'Auto Dealership',
    description: 'Sleek car dealership with hero section, test drive booking, vehicle gallery, and customer reviews.',
    imageUrl: 'https://images.pexels.com/photos/164634/pexels-photo-164634.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Automotive'
  },
  {
    id: 'restaurant',
    name: 'Restaurant',
    description: 'Appetizing restaurant site with hero, reservation booking, food gallery, and diner testimonials.',
    imageUrl: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Food & Beverage'
  },
  {
    id: 'real-estate',
    name: 'Real Estate',
    description: 'Premium property site with hero, viewing booking, virtual tour gallery, and client testimonials.',
    imageUrl: 'https://images.pexels.com/photos/1732414/pexels-photo-1732414.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Real Estate'
  },
  {
    id: 'medical-practice',
    name: 'Medical Practice',
    description: 'Professional healthcare site with hero, appointment booking, service gallery, and patient testimonials.',
    imageUrl: 'https://images.pexels.com/photos/4386466/pexels-photo-4386466.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Healthcare'
  },
  {
    id: 'personal-brand',
    name: 'Personal Brand',
    description: 'Showcase your expertise with hero section, about me, portfolio gallery, and client testimonials. Professional design.',
    imageUrl: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    category: 'Personal Branding'
  }
];

const categories = ['All', 'Beauty', 'Fitness', 'Automotive', 'Food & Beverage', 'Real Estate', 'Healthcare', 'Personal Branding'];

export default function TemplateGallery({ onSelectTemplate }: TemplateGalleryProps) {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredTemplates = activeCategory === 'All'
    ? templates
    : templates.filter(template => template.category === activeCategory);

  return (
    <section id="templates" className="relative py-20 px-4 sm:px-6 lg:px-8 bg-white pb-48">
      <div className="absolute bottom-0 left-0 right-0 h-[144px] pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-white via-slate-50 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-200/40 to-[#1B2A44]"></div>
      </div>

      <div className="absolute bottom-16 left-0 right-0 z-20 flex flex-col items-center gap-4 pointer-events-none">
        <p className="text-sm font-semibold text-white/60 tracking-wide animate-fade-in opacity-0" style={{ animationDelay: '0.3s', animationFillMode: 'forwards' }}>
          🌐 Everything you need to automate your business — powered by NewFoxX AI.
        </p>
        <div className="relative w-[70%] h-px">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-blue-400/25 to-transparent blur-lg"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-blue-400/20 to-transparent animate-shimmer"></div>
        </div>

        <div className="absolute top-16 left-1/2 -translate-x-1/2 w-full h-20 flex justify-center gap-8">
          <div className="w-1 h-full bg-blue-400/10 rounded-full animate-particle-drift" style={{ animationDelay: '0s' }}></div>
          <div className="w-1 h-full bg-purple-400/10 rounded-full animate-particle-drift" style={{ animationDelay: '2s' }}></div>
          <div className="w-1 h-full bg-blue-400/10 rounded-full animate-particle-drift" style={{ animationDelay: '4s' }}></div>
          <div className="w-1 h-full bg-purple-400/10 rounded-full animate-particle-drift" style={{ animationDelay: '6s' }}></div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Choose Your Template
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-8">
            Select from our curated collection of professional templates. Each one is fully customizable through our AI chat.
          </p>

          <div className="flex flex-wrap justify-center gap-3 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`px-6 py-2.5 rounded-full font-semibold text-sm transition-all duration-300 ${
                  activeCategory === category
                    ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/30'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 hover:shadow-md'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTemplates.map((template) => (
            <div
              key={template.id}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-md hover:shadow-2xl transition-all duration-500 border border-slate-200 animate-fade-in"
            >
              <div className="relative h-64 overflow-hidden">
                <img
                  src={template.imageUrl}
                  alt={template.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                <div className="absolute top-4 right-4">
                  <span className="px-3 py-1 bg-white/90 backdrop-blur-sm rounded-full text-xs font-semibold text-slate-700">
                    {template.category}
                  </span>
                </div>
              </div>

              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-2">
                  {template.name}
                </h3>
                <p className="text-slate-600 mb-6 text-sm leading-relaxed">
                  {template.description}
                </p>

                <button
                  onClick={() => onSelectTemplate(template)}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-lg font-semibold hover:bg-slate-800 transition-colors duration-300 group/btn"
                >
                  Choose Template
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
