import { useState, useEffect } from 'react';
import { Sparkles } from 'lucide-react';

const videos = [
  'https://cdn.pixabay.com/video/2023/07/31/174524-851847816_large.mp4',
  'https://cdn.pixabay.com/video/2022/11/09/138359-769786825_large.mp4'
];

export default function Hero() {
  const [currentVideo, setCurrentVideo] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentVideo((prev) => (prev + 1) % videos.length);
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="relative overflow-hidden h-screen min-h-[600px] text-white">
      {videos.map((video, index) => (
        <video
          key={video}
          autoPlay
          loop
          muted
          playsInline
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-2000 ${
            index === currentVideo ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <source src={video} type="video/mp4" />
        </video>
      ))}

      <div className="absolute inset-0 bg-gradient-to-br from-black/90 via-slate-900/85 to-black/90"></div>
      <div className="absolute inset-0 bg-black/40"></div>

      <div className="relative h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="text-center w-full">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-8 border border-white/20">
            <Sparkles className="w-4 h-4 text-yellow-300" />
            <span className="text-sm font-medium">Powered by AI</span>
          </div>

          <h1 className="text-5xl sm:text-6xl md:text-8xl font-bold tracking-tight mb-6 leading-tight">
            Automate Your Business
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-purple-400 bg-clip-text text-transparent">
              with NewFoxX AI
            </span>
          </h1>

          <p className="text-xl sm:text-2xl text-slate-200 max-w-3xl mx-auto mb-12 leading-relaxed">
            Choose your plan — Website, Ads, or Full AI System.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <a
              href="#templates"
              className="group px-10 py-5 bg-gradient-to-r from-blue-500 via-cyan-500 to-purple-500 rounded-xl font-bold text-white text-lg shadow-2xl shadow-blue-500/50 hover:shadow-blue-500/70 transition-all duration-300 hover:scale-105"
            >
              Get Started
              <span className="inline-block ml-2 group-hover:translate-x-1 transition-transform">→</span>
            </a>
            <a
              href="#templates"
              className="px-10 py-5 bg-white/10 backdrop-blur-md rounded-xl font-bold text-white text-lg border-2 border-white/30 hover:bg-white/20 transition-all duration-300"
            >
              View Templates
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent"></div>
    </section>
  );
}
