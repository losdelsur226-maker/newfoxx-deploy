import { Globe, Megaphone, MessageCircle, BarChart3 } from 'lucide-react';

const features = [
  {
    icon: Globe,
    title: 'Website Editing',
    description: 'Design, edit, and launch your website instantly with AI. NewFoxX builds it for you — complete with SEO optimization and a connected domain, ready to go live in minutes.',
    gradient: 'from-blue-500 to-cyan-500',
    bgType: 'website'
  },
  {
    icon: Megaphone,
    title: 'Ads Management',
    description: 'Full Meta management powered by AI — we create, optimize, and scale your campaigns automatically.',
    gradient: 'from-pink-500 to-rose-500',
    bgType: 'ads'
  },
  {
    icon: MessageCircle,
    title: 'Smart Chat Bot',
    description: 'An AI assistant that answers clients, captures leads, and automates responses 24/7.',
    gradient: 'from-emerald-500 to-teal-500',
    bgType: 'chat'
  },
  {
    icon: BarChart3,
    title: 'Analytics',
    description: 'Track your website\'s performance with key traffic and e-commerce metrics.',
    gradient: 'from-amber-500 to-orange-500',
    bgType: 'analytics',
    bgImage: '/image copy.png'
  }
];

export default function FeaturesSection() {
  return (
    <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-50 to-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            What We Offer
          </h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Power your day-to-day with all the tools and AI guidance you need to manage your business, seamlessly integrated in one place.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group relative bg-slate-900 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 border border-slate-700 hover:border-slate-600"
              >
                {feature.bgType === 'analytics' && feature.bgImage ? (
                  <div
                    className="absolute inset-0 opacity-40 group-hover:opacity-50 transition-opacity duration-500"
                    style={{
                      backgroundImage: `url(${feature.bgImage})`,
                      backgroundSize: 'cover',
                      backgroundPosition: 'center'
                    }}
                  ></div>
                ) : feature.bgType === 'website' ? (
                  <div className="absolute inset-0 opacity-30 group-hover:opacity-40 transition-opacity duration-500">
                    <div className="absolute top-8 left-8 right-8 h-32 bg-slate-700 rounded-lg"></div>
                    <div className="absolute top-12 left-12 right-12 h-6 bg-slate-600 rounded"></div>
                    <div className="absolute top-20 left-12 w-32 h-4 bg-slate-600 rounded"></div>
                    <div className="absolute top-20 right-12 w-24 h-4 bg-blue-500 rounded"></div>
                    <div className="absolute bottom-16 left-8 right-8 grid grid-cols-3 gap-3">
                      <div className="h-20 bg-slate-700 rounded"></div>
                      <div className="h-20 bg-slate-700 rounded"></div>
                      <div className="h-20 bg-slate-700 rounded"></div>
                    </div>
                  </div>
                ) : feature.bgType === 'ads' ? (
                  <div className="absolute inset-0 opacity-30 group-hover:opacity-40 transition-opacity duration-500">
                    <div className="absolute top-8 left-8 right-8 h-40 bg-gradient-to-br from-pink-600 to-rose-600 rounded-lg"></div>
                    <div className="absolute top-12 left-12 w-16 h-16 bg-white rounded-full opacity-80"></div>
                    <div className="absolute top-14 right-12 w-32 h-3 bg-white rounded opacity-60"></div>
                    <div className="absolute top-20 right-12 w-24 h-3 bg-white rounded opacity-60"></div>
                    <div className="absolute bottom-16 left-8 right-8 flex gap-3">
                      <div className="flex-1 h-16 bg-slate-700 rounded flex items-center justify-center">
                        <div className="w-8 h-8 border-2 border-slate-500 rounded-full"></div>
                      </div>
                      <div className="flex-1 h-16 bg-slate-700 rounded flex items-center justify-center">
                        <div className="text-slate-500 font-bold text-xs">👍</div>
                      </div>
                      <div className="flex-1 h-16 bg-slate-700 rounded flex items-center justify-center">
                        <div className="text-slate-500 font-bold text-xs">💬</div>
                      </div>
                    </div>
                  </div>
                ) : feature.bgType === 'chat' ? (
                  <div className="absolute inset-0 opacity-30 group-hover:opacity-40 transition-opacity duration-500">
                    <div className="absolute top-8 left-8 right-16 h-12 bg-slate-700 rounded-2xl rounded-bl-sm"></div>
                    <div className="absolute top-24 left-16 right-8 h-12 bg-emerald-600 rounded-2xl rounded-br-sm"></div>
                    <div className="absolute top-40 left-8 right-20 h-12 bg-slate-700 rounded-2xl rounded-bl-sm"></div>
                    <div className="absolute bottom-16 left-8 right-8 h-12 bg-slate-700 rounded-full flex items-center px-4">
                      <div className="w-24 h-3 bg-slate-600 rounded"></div>
                    </div>
                  </div>
                ) : null}

                <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/95 to-slate-900/80"></div>

                <div className="relative p-8 h-full flex flex-col">
                  <div className={`inline-flex p-4 rounded-xl bg-gradient-to-br ${feature.gradient} mb-6 group-hover:scale-110 transition-transform duration-300 self-start`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>

                  <h3 className="text-2xl font-bold text-white mb-4">
                    {feature.title}
                  </h3>

                  <p className="text-slate-300 leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-b-2xl from-blue-500 via-purple-500 to-pink-500"></div>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-slate-50 rounded-full border border-slate-200">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 border-2 border-white"></div>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-400 to-pink-600 border-2 border-white"></div>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 border-2 border-white"></div>
            </div>
            <span className="text-sm font-semibold text-slate-700">
              Everything you need to grow your business
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
