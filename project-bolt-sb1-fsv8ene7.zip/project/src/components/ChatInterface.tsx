import { useState, useEffect, useRef } from 'react';
import { Send, X, Bot, User, Sparkles, CheckCircle2 } from 'lucide-react';
import type { Template, ChatMessage, WebsiteData } from '../types';

interface ChatInterfaceProps {
  template: Template;
  onClose: () => void;
}

const questions = [
  { id: 'businessName', question: "What's your business name?" },
  { id: 'colors', question: "What colors or style do you prefer? (e.g., modern blue, warm earth tones, minimalist black & white)" },
  { id: 'features', question: "What features do you need? (e.g., booking form, contact form, gallery, testimonials)" },
  { id: 'logo', question: "Do you have a logo? If yes, describe it or paste a URL. If not, we can help create one!" },
  { id: 'additionalInfo', question: "Any other specific requirements or information about your business?" }
];

export default function ChatInterface({ template, onClose }: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentInput, setCurrentInput] = useState('');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [_websiteData, setWebsiteData] = useState<WebsiteData>({ templateId: template.id });
  const [isGenerating, setIsGenerating] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const welcomeMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'bot',
      content: `Great choice! Let's customize your ${template.name} website. I'll ask you a few questions to understand your needs better.`,
      timestamp: Date.now()
    };

    const firstQuestion: ChatMessage = {
      id: `msg-${Date.now() + 1}`,
      role: 'bot',
      content: questions[0].question,
      timestamp: Date.now() + 100
    };

    setMessages([welcomeMessage, firstQuestion]);
  }, [template]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (!isGenerating && !isComplete) {
      inputRef.current?.focus();
    }
  }, [messages, isGenerating, isComplete]);

  const handleSendMessage = () => {
    if (!currentInput.trim() || isGenerating) return;

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: currentInput,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);

    const currentQuestion = questions[currentQuestionIndex];
    setWebsiteData(prev => ({
      ...prev,
      [currentQuestion.id]: currentInput
    }));

    setCurrentInput('');

    setTimeout(() => {
      if (currentQuestionIndex < questions.length - 1) {
        const nextQuestion: ChatMessage = {
          id: `msg-${Date.now()}`,
          role: 'bot',
          content: questions[currentQuestionIndex + 1].question,
          timestamp: Date.now()
        };
        setMessages(prev => [...prev, nextQuestion]);
        setCurrentQuestionIndex(prev => prev + 1);
      } else {
        const finalMessage: ChatMessage = {
          id: `msg-${Date.now()}`,
          role: 'bot',
          content: "Perfect! I have everything I need. Ready to generate your website?",
          timestamp: Date.now()
        };
        setMessages(prev => [...prev, finalMessage]);
      }
    }, 800);
  };

  const handleGenerateWebsite = () => {
    setIsGenerating(true);

    const generatingMessage: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'bot',
      content: "Generating your website...",
      timestamp: Date.now()
    };
    setMessages(prev => [...prev, generatingMessage]);

    setTimeout(() => {
      setIsGenerating(false);
      setIsComplete(true);
      const successMessage: ChatMessage = {
        id: `msg-${Date.now()}`,
        role: 'bot',
        content: "Your website is being built! 🎉",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, successMessage]);
    }, 3000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const showGenerateButton = currentQuestionIndex === questions.length - 1 &&
    messages.some(m => m.content.includes("Ready to generate"));

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl h-[80vh] flex flex-col overflow-hidden">
        <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/10 rounded-lg backdrop-blur-sm">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-semibold">NewFoxX AI Assistant</h3>
              <p className="text-xs text-slate-300">Customizing your {template.name} template</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Close chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {message.role === 'bot' && (
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                  <Bot className="w-5 h-5 text-white" />
                </div>
              )}

              <div
                className={`max-w-[75%] rounded-2xl px-4 py-3 ${
                  message.role === 'user'
                    ? 'bg-slate-900 text-white'
                    : 'bg-white text-slate-900 shadow-sm border border-slate-200'
                }`}
              >
                <p className="text-sm leading-relaxed">{message.content}</p>
              </div>

              {message.role === 'user' && (
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-300 flex items-center justify-center">
                  <User className="w-5 h-5 text-slate-700" />
                </div>
              )}
            </div>
          ))}

          {isGenerating && (
            <div className="flex gap-3 justify-start">
              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white animate-pulse" />
              </div>
              <div className="bg-white rounded-2xl px-4 py-3 shadow-sm border border-slate-200">
                <div className="flex gap-2">
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {!isComplete && (
          <div className="border-t border-slate-200 p-4 bg-white">
            {showGenerateButton ? (
              <button
                onClick={handleGenerateWebsite}
                disabled={isGenerating}
                className="w-full flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-blue-500 to-cyan-500 text-white rounded-xl font-semibold shadow-lg shadow-blue-500/50 hover:shadow-xl hover:shadow-blue-500/60 transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
              >
                <Sparkles className="w-5 h-5" />
                Generate My Website
              </button>
            ) : (
              <div className="flex gap-2">
                <input
                  ref={inputRef}
                  type="text"
                  value={currentInput}
                  onChange={(e) => setCurrentInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your answer..."
                  disabled={isGenerating}
                  className="flex-1 px-4 py-3 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed"
                />
                <button
                  onClick={handleSendMessage}
                  disabled={!currentInput.trim() || isGenerating}
                  className="px-6 py-3 bg-slate-900 text-white rounded-xl font-semibold hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Send className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {isComplete && (
          <div className="border-t border-slate-200 p-6 bg-gradient-to-r from-green-50 to-emerald-50">
            <div className="flex items-center justify-center gap-3 text-green-700">
              <CheckCircle2 className="w-6 h-6" />
              <p className="font-semibold">Website generation started successfully!</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
