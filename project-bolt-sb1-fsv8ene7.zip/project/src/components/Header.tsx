import { useState, useRef, useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Zap, ChevronDown, Sparkles, PenTool, Search, Globe, Megaphone, Facebook, MessageCircle, BarChart3, Users, Headphones, Zap as ZapIcon } from 'lucide-react';

export default function Header() {
  const location = useLocation();
  const navigate = useNavigate();
  const isHomePage = location.pathname === '/';
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    setIsProductsOpen(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setIsProductsOpen(false);
    }, 200);
  };

  const handleLinkClick = (sectionId: string) => {
    setIsProductsOpen(false);
    if (!isHomePage) {
      navigate(`/#${sectionId}`);
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    }
  };

  useEffect(() => {
    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, []);

  return (
    <header className="absolute top-0 left-0 right-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="p-2 bg-white/10 backdrop-blur-sm rounded-lg">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">NewFoxX</span>
          </Link>

          <nav className="hidden lg:flex items-center gap-8">
            <div
              className="relative"
              onMouseEnter={handleMouseEnter}
              onMouseLeave={handleMouseLeave}
            >
              <button className="flex items-center gap-1 text-white/90 hover:text-white transition-colors font-medium py-2">
                Products
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isProductsOpen ? 'rotate-180' : ''}`} />
              </button>

              {isProductsOpen && (
                <div className="absolute top-full left-1/2 -translate-x-1/2 pt-2 -mt-2">
                  <div className="w-[800px] bg-slate-900/95 backdrop-blur-xl border border-slate-700/50 rounded-2xl shadow-2xl p-8 animate-dropdown">
                    <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-900 border-l border-t border-slate-700/50 rotate-45"></div>

                  <div className="grid grid-cols-3 gap-8">
                    <div>
                      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Website</h3>
                      <div className="space-y-3">
                        <a href="#website" onClick={() => handleLinkClick('website')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-blue-500/10 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                            <Sparkles className="w-4 h-4 text-blue-400" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-white font-semibold text-sm">AI Website Builder</p>
                              <span className="px-1.5 py-0.5 bg-blue-500/20 text-blue-400 text-xs font-semibold rounded">New</span>
                            </div>
                            <p className="text-slate-400 text-xs mt-0.5">Build your website automatically with AI</p>
                          </div>
                        </a>

                        <a href="#website" onClick={() => handleLinkClick('website')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-purple-500/10 rounded-lg group-hover:bg-purple-500/20 transition-colors">
                            <PenTool className="w-4 h-4 text-purple-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">Smart Editor</p>
                            <p className="text-slate-400 text-xs mt-0.5">Customize with drag-and-drop control</p>
                          </div>
                        </a>

                        <a href="#website" onClick={() => handleLinkClick('website')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-green-500/10 rounded-lg group-hover:bg-green-500/20 transition-colors">
                            <Search className="w-4 h-4 text-green-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">SEO Optimization</p>
                            <p className="text-slate-400 text-xs mt-0.5">AI-powered keywords and meta setup</p>
                          </div>
                        </a>

                        <a href="#website" onClick={() => handleLinkClick('website')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                            <Globe className="w-4 h-4 text-cyan-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">Domains & Hosting</p>
                            <p className="text-slate-400 text-xs mt-0.5">Everything included, no setup required</p>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Marketing</h3>
                      <div className="space-y-3">
                        <a href="#ads" onClick={() => handleLinkClick('ads')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-pink-500/10 rounded-lg group-hover:bg-pink-500/20 transition-colors">
                            <Megaphone className="w-4 h-4 text-pink-400" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-white font-semibold text-sm">AI Ad Bot</p>
                              <span className="px-1.5 py-0.5 bg-pink-500/20 text-pink-400 text-xs font-semibold rounded">New</span>
                            </div>
                            <p className="text-slate-400 text-xs mt-0.5">Create, launch, and manage ads automatically</p>
                          </div>
                        </a>

                        <a href="#ads" onClick={() => handleLinkClick('ads')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-blue-500/10 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                            <Facebook className="w-4 h-4 text-blue-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">Meta Ads Manager</p>
                            <p className="text-slate-400 text-xs mt-0.5">Full integration for Facebook & Instagram</p>
                          </div>
                        </a>

                        <a href="#ads" onClick={() => handleLinkClick('ads')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-red-500/10 rounded-lg group-hover:bg-red-500/20 transition-colors">
                            <Search className="w-4 h-4 text-red-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">Google Ads Integration</p>
                            <p className="text-slate-400 text-xs mt-0.5">Optional expansion for advanced users</p>
                          </div>
                        </a>

                        <a href="#ads" onClick={() => handleLinkClick('ads')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-purple-500/10 rounded-lg group-hover:bg-purple-500/20 transition-colors">
                            <MessageCircle className="w-4 h-4 text-purple-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">Smart Chat Bot</p>
                            <p className="text-slate-400 text-xs mt-0.5">Capture leads and answer clients 24/7</p>
                          </div>
                        </a>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">Business Tools</h3>
                      <div className="space-y-3">
                        <a href="#assistant" onClick={() => handleLinkClick('assistant')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-cyan-500/10 rounded-lg group-hover:bg-cyan-500/20 transition-colors">
                            <BarChart3 className="w-4 h-4 text-cyan-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">Analytics Dashboard</p>
                            <p className="text-slate-400 text-xs mt-0.5">Track performance and conversions in real time</p>
                          </div>
                        </a>

                        <a href="#assistant" onClick={() => handleLinkClick('assistant')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-green-500/10 rounded-lg group-hover:bg-green-500/20 transition-colors">
                            <Users className="w-4 h-4 text-green-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">CRM Integration</p>
                            <p className="text-slate-400 text-xs mt-0.5">Manage clients and automate follow-ups</p>
                          </div>
                        </a>

                        <a href="#assistant" onClick={() => handleLinkClick('assistant')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-blue-500/10 rounded-lg group-hover:bg-blue-500/20 transition-colors">
                            <Headphones className="w-4 h-4 text-blue-400" />
                          </div>
                          <div>
                            <p className="text-white font-semibold text-sm">24/7 AI Support</p>
                            <p className="text-slate-400 text-xs mt-0.5">Instant help from your built-in assistant</p>
                          </div>
                        </a>

                        <a href="#assistant" onClick={() => handleLinkClick('assistant')} className="group flex items-start gap-3 p-2 rounded-lg hover:bg-slate-800/50 transition-colors">
                          <div className="p-2 bg-orange-500/10 rounded-lg group-hover:bg-orange-500/20 transition-colors">
                            <ZapIcon className="w-4 h-4 text-orange-400" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-white font-semibold text-sm">Automation Hub</p>
                              <span className="px-1.5 py-0.5 bg-orange-500/20 text-orange-400 text-xs font-semibold rounded">Coming Soon</span>
                            </div>
                            <p className="text-slate-400 text-xs mt-0.5">Automate invoices, bookings, and messages</p>
                          </div>
                        </a>
                      </div>
                    </div>
                  </div>
                  </div>
                </div>
              )}
            </div>

            {isHomePage && (
              <>
                <a href="#templates" className="text-white/90 hover:text-white transition-colors font-medium">
                  Templates
                </a>
                <a href="#features" className="text-white/90 hover:text-white transition-colors font-medium">
                  Features
                </a>
              </>
            )}
            <Link to="/pricing" className="text-white/90 hover:text-white transition-colors font-medium">
              Pricing
            </Link>
            {isHomePage && (
              <a href="#help" className="text-white/90 hover:text-white transition-colors font-medium">
                Help
              </a>
            )}
          </nav>

          <button className="px-6 py-2 bg-white text-slate-900 rounded-lg font-semibold hover:bg-white/90 transition-colors">
            Sign In
          </button>
        </div>
      </div>
    </header>
  );
}
