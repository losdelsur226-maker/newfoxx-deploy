import { useState, useEffect } from 'react';

const businessTemplates = [
  {
    name: 'E-commerce Fashion Store',
    description: 'Modern online clothing boutique with shopping cart',
    gradient: 'from-pink-500 to-rose-600',
    icon: '👗'
  },
  {
    name: 'Hair Salon & Spa',
    description: 'Elegant booking system for beauty services',
    gradient: 'from-purple-500 to-pink-600',
    icon: '💇'
  },
  {
    name: 'Barber Shop',
    description: 'Professional grooming with appointment scheduling',
    gradient: 'from-slate-700 to-slate-900',
    icon: '✂️'
  },
  {
    name: 'Fitness Gym',
    description: 'Membership plans and class schedules',
    gradient: 'from-orange-500 to-red-600',
    icon: '💪'
  },
  {
    name: 'Auto Dealership',
    description: 'Vehicle inventory with financing options',
    gradient: 'from-blue-600 to-indigo-700',
    icon: '🚗'
  },
  {
    name: 'Restaurant & Cafe',
    description: 'Menu display with online ordering',
    gradient: 'from-amber-500 to-orange-600',
    icon: '🍽️'
  },
  {
    name: 'Real Estate Agency',
    description: 'Property listings with virtual tours',
    gradient: 'from-teal-500 to-cyan-600',
    icon: '🏠'
  },
  {
    name: 'Medical Practice',
    description: 'Patient portal and appointment booking',
    gradient: 'from-blue-500 to-blue-700',
    icon: '⚕️'
  }
];

export default function TemplateShowcase() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setIsAnimating(true);
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % businessTemplates.length);
        setIsAnimating(false);
      }, 500);
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const current = businessTemplates[currentIndex];

  return (
    <section className="py-24 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Perfect For Any Business
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            AI-powered templates tailored to your industry
          </p>
        </div>

        <div className="relative max-w-4xl mx-auto">
          <div
            className={`transition-all duration-500 transform ${
              isAnimating ? 'scale-95 opacity-50' : 'scale-100 opacity-100'
            }`}
          >
            <div className={`relative h-96 rounded-3xl bg-gradient-to-br ${current.gradient} shadow-2xl overflow-hidden`}>
              <div className="absolute inset-0 bg-black/20"></div>

              <div className="relative h-full flex flex-col items-center justify-center p-12 text-white">
                <div className="text-8xl mb-6 animate-bounce">
                  {current.icon}
                </div>
                <h3 className="text-4xl sm:text-5xl font-bold mb-4 text-center">
                  {current.name}
                </h3>
                <p className="text-xl text-white/90 text-center max-w-md">
                  {current.description}
                </p>
              </div>

              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex gap-2">
                {businessTemplates.map((_, index) => (
                  <div
                    key={index}
                    className={`h-2 rounded-full transition-all duration-300 ${
                      index === currentIndex
                        ? 'w-8 bg-white'
                        : 'w-2 bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

        </div>

        <div className="text-center mt-16">
          <p className="text-lg text-slate-700">
            Join <span className="font-bold text-slate-900">millions of entrepreneurs</span> who run their business on <span className="font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">NewFoxX</span>
          </p>
        </div>
      </div>
    </section>
  );
}
