import { Bot, MessageSquare, Zap, BarChart2, ArrowRight, Play } from 'lucide-react';

const features = [
  {
    icon: MessageSquare,
    title: 'Ad Creation with AI',
    description: 'The bot chats with you, writes headlines, captions, and targeting in seconds.'
  },
  {
    icon: Zap,
    title: '1-Click Publish',
    description: 'Approve your ad, and it automatically goes live on Facebook or Instagram.'
  },
  {
    icon: BarChart2,
    title: 'Auto Management',
    description: 'The system monitors performance and pauses when you stop paying (subscription-based access).'
  }
];

export default function AIAdBot() {
  return (
    <section className="relative py-24 px-4 sm:px-6 lg:px-8 overflow-hidden bg-gradient-to-b from-[#1B2A44] via-[#0A1428] to-blue-950 -mt-48 pt-56">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-64 bg-gradient-radial from-blue-500/20 via-purple-500/10 to-transparent blur-3xl opacity-60 pointer-events-none animate-glow-pulse"></div>

      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute w-96 h-96 -top-48 -left-48 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute w-96 h-96 -bottom-48 -right-48 bg-purple-500/10 rounded-full blur-3xl"></div>
        <div className="absolute w-64 h-64 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-cyan-500/5 rounded-full blur-3xl"></div>
      </div>

      <div className="absolute inset-0" style={{
        backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(59, 130, 246, 0.15) 1px, transparent 0)',
        backgroundSize: '40px 40px'
      }}></div>

      <div className="relative max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-500/10 border border-blue-500/20 rounded-full mb-6">
            <Bot className="w-5 h-5 text-blue-400" />
            <span className="text-sm font-semibold text-blue-300">Powered by AI</span>
          </div>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6">
            AI Ad Bot — Your Personal{' '}
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text">
              Ad Manager
            </span>
          </h2>
          <p className="text-xl text-slate-300 max-w-3xl mx-auto">
            Create, launch, and manage ads automatically with NewFoxX AI.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-3xl blur-xl opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>
            <div className="relative bg-slate-900/80 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 shadow-2xl">
              <div className="flex items-center gap-3 mb-6 pb-4 border-b border-slate-700">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                  <Bot className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-semibold text-white">NewFoxX AI Bot</div>
                  <div className="text-xs text-green-400 flex items-center gap-1">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    Active
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 bg-slate-800/50 rounded-2xl rounded-tl-sm p-4">
                    <p className="text-slate-300 text-sm leading-relaxed">
                      Hi! I've analyzed your business. Ready to create your first ad campaign?
                    </p>
                  </div>
                </div>

                <div className="flex gap-3 justify-end">
                  <div className="flex-1 max-w-xs bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl rounded-tr-sm p-4">
                    <p className="text-white text-sm leading-relaxed">
                      Yes! Create an ad for my new product launch.
                    </p>
                  </div>
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs">
                    👤
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div className="flex-1 bg-slate-800/50 rounded-2xl rounded-tl-sm p-4">
                    <p className="text-slate-300 text-sm font-semibold mb-3">Your ad is ready!</p>
                    <div className="bg-slate-900/80 rounded-lg p-3 mb-3 border border-slate-700">
                      <div className="text-xs text-blue-400 mb-1">Headline:</div>
                      <div className="text-white text-sm font-medium mb-2">Limited Time: 30% Off New Collection</div>
                      <div className="text-xs text-blue-400 mb-1">Caption:</div>
                      <div className="text-slate-300 text-xs">Don't miss out on our exclusive launch offer...</div>
                    </div>
                    <button className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white text-sm font-semibold py-2 px-4 rounded-lg hover:shadow-lg transition-all">
                      Publish Now →
                    </button>
                  </div>
                </div>

                <div className="flex gap-2 items-center px-4">
                  <div className="flex-1 h-10 bg-slate-800/50 rounded-full flex items-center px-4">
                    <span className="text-slate-500 text-sm">Type your message...</span>
                  </div>
                  <button className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center hover:scale-110 transition-transform">
                    <MessageSquare className="w-5 h-5 text-white" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Bot className="w-6 h-6 text-blue-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">AI-Powered Automation</h3>
                <p className="text-slate-400 leading-relaxed">
                  Our intelligent bot handles everything from creative generation to campaign optimization, giving you more time to focus on your business.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-500/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Zap className="w-6 h-6 text-purple-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Launch in Minutes</h3>
                <p className="text-slate-400 leading-relaxed">
                  No more hours of ad setup. Just chat with the bot, review your ad, and publish instantly to Facebook and Instagram.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 group">
              <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-pink-500/20 to-rose-500/20 border border-pink-500/30 flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <BarChart2 className="w-6 h-6 text-pink-400" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-white mb-2">Smart Management</h3>
                <p className="text-slate-400 leading-relaxed">
                  Real-time performance monitoring with automatic optimization. Your subscription keeps everything running smoothly.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group relative bg-slate-900/50 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 hover:border-blue-500/50 transition-all duration-500 hover:-translate-y-2"
              >
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 rounded-2xl transition-opacity duration-500"></div>

                <div className="relative">
                  <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-blue-500/30 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-7 h-7 text-blue-400" />
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3">
                    {feature.title}
                  </h3>

                  <p className="text-slate-400 leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-b-2xl"></div>
              </div>
            );
          })}
        </div>

        <div className="text-center">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button className="group px-8 py-4 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white font-bold rounded-xl hover:shadow-2xl hover:shadow-blue-500/50 transition-all duration-300 hover:scale-105 flex items-center gap-2">
              Start My AI Bot
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="group px-8 py-4 bg-slate-800/50 backdrop-blur-sm border border-slate-700 text-white font-semibold rounded-xl hover:border-blue-500/50 transition-all duration-300 hover:bg-slate-800 flex items-center gap-2">
              <Play className="w-5 h-5" />
              See How It Works
            </button>
          </div>
          <p className="text-slate-500 text-sm mt-6">
            Subscription-based • Cancel anytime • 14-day money-back guarantee
          </p>
        </div>
      </div>
    </section>
  );
}
