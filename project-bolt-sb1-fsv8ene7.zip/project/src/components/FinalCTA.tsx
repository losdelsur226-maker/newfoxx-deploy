import { Rocket, MessageCircle, ArrowRight } from 'lucide-react';

export default function FinalCTA() {
  return (
    <>
      <section className="relative py-32 px-4 sm:px-6 lg:px-8 overflow-hidden bg-black">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute w-[600px] h-[600px] top-1/2 left-1/4 -translate-x-1/2 -translate-y-1/2 bg-blue-500/20 rounded-full blur-[120px] animate-glow-pulse"></div>
          <div className="absolute w-[500px] h-[500px] top-1/2 right-1/4 translate-x-1/2 -translate-y-1/2 bg-purple-500/20 rounded-full blur-[120px] animate-glow-pulse" style={{ animationDelay: '3s' }}></div>
          <div className="absolute w-[400px] h-[400px] bottom-0 left-1/2 -translate-x-1/2 bg-pink-500/15 rounded-full blur-[100px]"></div>
        </div>

        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, rgba(96, 165, 250, 0.08) 1px, transparent 0)',
          backgroundSize: '50px 50px'
        }}></div>

        <div className="relative max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 border border-blue-400/20 rounded-full mb-8 animate-fade-in opacity-0" style={{ animationDelay: '0.2s', animationFillMode: 'forwards' }}>
            <Rocket className="w-4 h-4 text-blue-400" />
            <span className="text-sm font-semibold bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text">
              Build. Automate. Grow.
            </span>
          </div>

          <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold text-white mb-6 animate-fade-in opacity-0" style={{ animationDelay: '0.4s', animationFillMode: 'forwards' }}>
            Start your free{' '}
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text">
              AI-powered website
            </span>{' '}
            trial today.
          </h2>

          <p className="text-xl text-slate-400 mb-12 animate-fade-in opacity-0" style={{ animationDelay: '0.6s', animationFillMode: 'forwards' }}>
            No credit card required. Cancel anytime.
          </p>

          <button className="group relative px-10 py-5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl font-bold text-lg text-white shadow-2xl hover:shadow-purple-500/50 transition-all duration-300 hover:-translate-y-2 hover:scale-105 overflow-hidden animate-fade-in opacity-0" style={{ animationDelay: '0.8s', animationFillMode: 'forwards' }}>
            <span className="relative z-10 flex items-center justify-center gap-2">
              Get Started
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </span>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="absolute inset-0 bg-white/20 blur-xl"></div>
            </div>
          </button>
        </div>
      </section>

      <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-black to-slate-950">
        <div className="relative max-w-2xl mx-auto">
          <div className="group relative animate-float">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-3xl blur-lg opacity-30 group-hover:opacity-50 transition-opacity duration-500"></div>

            <div className="relative bg-gradient-to-br from-slate-900/95 to-slate-950/95 backdrop-blur-sm border border-slate-700/50 rounded-2xl p-8 shadow-2xl text-center">
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 mb-4 group-hover:scale-110 transition-transform duration-300">
                <MessageCircle className="w-7 h-7 text-white" />
              </div>

              <p className="text-lg sm:text-xl font-semibold text-white mb-2">
                💬 Have questions or doubts?{' '}
                <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 text-transparent bg-clip-text">
                  Chat with our AI Assistant 24/7.
                </span>
              </p>

              <p className="text-sm text-slate-400 mb-6">
                Instant answers. Real support. Always online.
              </p>

              <button className="group/btn relative px-8 py-3 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-xl font-semibold text-white shadow-lg hover:shadow-purple-500/50 transition-all duration-300 hover:-translate-y-1 overflow-hidden">
                <span className="relative z-10 flex items-center justify-center gap-2">
                  Ask NewFoxX AI
                  <ArrowRight className="w-5 h-5 group-hover/btn:translate-x-1 transition-transform duration-300" />
                </span>
                <div className="absolute inset-0 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300"></div>
              </button>

              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none">
                <div className="absolute top-4 left-8 w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse"></div>
                <div className="absolute bottom-4 right-8 w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
                <div className="absolute top-8 right-12 w-1 h-1 bg-pink-400 rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
